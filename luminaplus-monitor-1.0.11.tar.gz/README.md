# LuminaPlus · Monitor 1.0.2

这是适配 **monitor-probe/monitor（Rust Hub）** 的主题安装包，不是 CF-Server-Monitor 的原版部署包。
原版 LuminaPlus 前端版本为 1.2.16，适配包版本为 1.0.2。

## 安装

1. 打开 https://z.wpxx.de/admin 并登录。
2. 进入「主题」，点击「上传主题包」，选择 `luminaplus-monitor-1.0.3.tar.gz`。不要解压后逐个上传，不要上传源码 ZIP。
3. 在主题列表找到 **LuminaPlus · Monitor**，选择启用。
4. 打开站点首页并强制刷新（Ctrl+F5）。
5. 原主题仍在列表中，可随时切换回去；不需要重装主控、替换 Agent 或修改 Caddy。

本包 short 为 `luminaplus-monitor`，不会覆盖原来的 Mr.Gu 主题。以后上传相同 short 的包会整体替换本主题，请保存自定义配置备份。

## 线路与历史

- 先在 Monitor 后台「延迟」创建探测任务并分配节点。主题只显示已经采集的结果，不会自行发起探测。
- 自动发现任务编号，最多映射 8 条；默认大卡/小卡展示前 3 条。点击卡片线路名可替换当前行；「主题设置」可调整展示条数和逐节点绑定。
- 未配置或未采样显示空白；已测整轮超时显示红格；延迟和丢包各自一条。鼠标悬停或手机点柱子查看时段及数值。
- 首页读取最近 1 小时历史，每约 1 分钟更新；实时资源通过主控 WebSocket 更新。
- 迷你卡和列表保持上游的紧凑单线路设计；需要同时查看多线路请选大卡或小卡。
- 访客最多查看 1 天；在同域名 `/admin` 登录后返回首页刷新，可选 7 天。实际长度取决于主控保留策略和已采集天数。
- 延迟取主控聚合结果，长时间范围可能平滑短峰；空白不等于 0% 丢包。详情页整窗丢包率使用主控提供的值，卡片/色带为所显示样本的统计，可能因窗口和聚合方式不同而有差异。

## 单位和数据

上行 = Agent 发送 net_tx，下行 = 接收 net_rx。速率按十进制 B/s、KB/s、MB/s、GB/s 显示：99,000,000 B/s = 99 MB/s，没有额外乘 8。容量/累计流量沿用原主题二进制换算。

价格、到期、流量限额、计费方向和本周期使用量读取 Monitor 节点配置。未填的字段不猜测。资产汇总沿用上游汇率服务，仅请求汇率，不发送节点资料；可在主题设置关闭。

Windows 不提供 Linux load average，显示「—」。主控没有保存 load average 历史，因此历史区展示 CPU、内存、磁盘、网络等已有指标；不能凭空恢复 Linux load average 历史。资源历史容量使用节点当前容量。

## 自定义默认设置

右上角展开快捷按钮，可切换亮/暗色、大卡/小卡/迷你卡/列表，进入「主题设置」。保存到本机仅影响当前浏览器。要让所有访客使用统一预设：

1. 在设置页调整并复制配置 JSON。
2. 解压上传包，将复制内容作为 `dist/lumina-config.json` 的 `themeOptions` 对象。
3. 保持 `theme.json`、`preview.png`、`dist/` 位于压缩包根目录，重新打包并上传。
4. 已保存本地偏好的设备需在主题设置「跟随站点」或清除本地设置才会使用新预设。

`lumina-config.json` 示例（任务编号和节点编号须替换成自己的）：

```json
{
  "title": "我的探针",
  "probeIds": [11, 22, 33, 44, 55, 66, 77, 88],
  "nodeGroups": {"1": "主力", "2": "吃灰"},
  "nodeTags": {"1": "CN2 GIA"},
  "themeOptions": {
    "desktopNodeViewMode": "large",
    "mobileNodeViewMode": "compact",
    "enableHomepageMultiPing": true,
    "homepageMultiPingTaskIds": [1, 2, 3],
    "fakePingForUnbound": false
  }
}
```

`probeIds` 是真实主控任务编号，空数组表示自动发现；`homepageMultiPingTaskIds` 是映射后的槽位 1～8。超过 8 个任务时用 `probeIds` 选取需要显示的 8 个。建议确定后固定该数组，防止任务增删后不同浏览器自动发现顺序不一致。此文件公开，禁止放 Token、密码或私密备注。

修改已构建包无需 Node：

```powershell
mkdir theme-edit
 tar -xzf .\luminaplus-monitor-1.0.3.tar.gz -C .\theme-edit
# 编辑 theme-edit\dist\lumina-config.json
 tar -czf .\theme.tar.gz -C .\theme-edit theme.json preview.png LICENSE ASSET-SOURCES.md README.md dist
```

## 源码构建

Node.js 22.12+，pnpm 10。源码 ZIP 解压后：

```powershell
pnpm install --frozen-lockfile --ignore-scripts
pnpm typecheck
pnpm exec vite build
pnpm exec vitest run src/services/__tests__/monitor.test.ts src/hooks/__tests__/usePingOverview.test.ts src/components/node/__tests__/touchBucketPick.test.ts src/components/instance/__tests__/chartData.test.ts src/components/instance/__tests__/PingChart.test.ts src/utils/__tests__/pingLineOverrides.test.ts src/hooks/__tests__/useViewMode.test.ts
 tar -czf .\theme.tar.gz theme.json preview.png LICENSE ASSET-SOURCES.md README.md dist
```

构建使用 pnpm-lock.yaml。保留上游测试用于参考，其中 CFSM 专用接口测试不适用于此适配层；以上为本次兼容性验收范围。

本地 UI 预览：构建后 `node scripts/preview-monitor.mjs`，打开 http://localhost:38179 。该服务使用模拟数据；`/mock-login` 只模拟本地登录。服务脚本和测试数据不进入上传包的 dist，不连接你的 VPS。

## 验证范围

已核对主控源码接口与主题包规范，并使用模拟主控进行接口测试和浏览器检查；没有登录或修改你的 VPS，因此线上安装与真实历史仍需安装后验收。

适配仅调用同源 `/api/nodes`、`/api/ws` 和 `/api/nodes/{id}/metrics`；身份沿用主控 Cookie。没有 CFSM JWT 登录、后端设置写入或 Agent 控制功能。前端隐藏非公开节点，不在主题配置保存认证信息。

## 来源

- LuminaPlus: https://github.com/volcano-1025/CFSM-Theme-LuminaPlus ，提交 `6403ccefbfa705fef4109dda5f24e12c48042d80`，MIT，保留 LICENSE。
- 兼容性依据: monitor-probe/monitor 提交 `2b155a3c1d50c420fb2cd3e85ba2e3cac7906b6e`。
- 国旗/系统图标来源见 ASSET-SOURCES.md。主题原版说明保留为 UPSTREAM-README.md，仅供追溯，不用于本包部署。

## 1.0.2 更新
首屏不再等待全节点延迟历史；配置与节点并行读取并合并重复请求，历史后台加载后刷新。删除页面底部署名及其版本检查；源码许可证保留。新增慢历史接口不阻塞首屏的回归测试。


## 1.0.2 界面调整
大卡移除顶部重复分组，底部分组保留。详情资源栏增加价格，网络栏增加到期剩余天数；未配置显示未设置，过期显示已过期。

## 1.0.3
顶部名称及浏览器标题优先读取主控 /api/me 的 site_name，读取失败时才使用包内 title。该请求后台进行，不阻塞节点首屏。详情价格与到期剩余统一放在网络栏底部，价格在上。

## 1.0.4
详情总流量改为右对齐，下一行新增剩余流量，按主控本周期计费规则计算；无限额显示不限量，超额显示 0 B。

## 1.0.5
详情到期显示日期与剩余天数；资产概览入口移到顶部快捷区；首页第四张卡显示可见在线节点中实时上下行速率合计最大的节点，点击名称进入详情。首页默认不再预取汇率。


## 1.0.6
离线及状态未确认节点置底；详情移除负载行，新增启动时间和最后更新（浏览器本地时区完整日期时间），位于运行时长上方。主控未提供启动信息时显示 —。

## 1.0.7
资源栏恢复负载行，运行时长移到右侧网络栏的到期下面；启动时间和最后更新保持在资源栏。

## 1.0.8
最忙节点卡说明改为带宽并右对齐；PC 默认迷你卡片，手机默认小卡不变。已保存的本机布局偏好优先，需在主题设置恢复跟随站点以使用新默认布局。

## 1.0.9
地区与系统分组合并到同一筛选栏，取消独立地区行；空间不足时自动换行，原筛选功能保留。

## 1.0.10

- 电脑端默认恢复大卡片视图，保留访客已保存的视图偏好。
- 移动端隐藏排序按钮，系统和地区筛选栏占满整行。

## 1.0.11

- 页面底部增加 Monitor | LuminaPlus | Powered by monitor，最后的 monitor 链接到 Monitor 项目。
